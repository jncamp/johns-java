package com.thymeleaf.demo.services;

import java.util.List;

import com.thymeleaf.demo.models.Person;
import com.thymeleaf.demo.repositories.PersonRepository;

public interface PersonService extends PersonRepository {
   List<Person> findAllPersons();
}
