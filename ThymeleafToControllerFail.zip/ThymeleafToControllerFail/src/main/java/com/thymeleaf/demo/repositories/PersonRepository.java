package com.thymeleaf.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thymeleaf.demo.models.Person;

public interface PersonRepository  extends JpaRepository <Person,Integer>{
   
}
