package com.thymeleaf.demo.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.thymeleaf.demo.models.Person;
import com.thymeleaf.demo.services.PersonService;

@Controller
public class MainController {
	@Autowired
	private PersonService personService;

	@RequestMapping("/")
	String showMainPage(Model model) {
		List<Person> persons = personService.findAll();
		model.addAttribute("personBind", persons);
		model.addAttribute("personList",persons);
		return "index";
	}
	
	@RequestMapping(value = "/editpersons", params = "btnSaveEdit", method = RequestMethod.POST)
    public String saveEditPersons(@ModelAttribute ArrayList<Person> personList){
		System.out.println("inside edit code personsList size = " + personList.size());
		for (Person p : personList) {
			System.out.println("person is " + p.getName());
		}
        return "index";
    }
}
